#print("Welkom bijPapi Gelato je mag alle smaken kiezen zolang het maar vanille ijs is.")
#aantal = int(input("Hoeveel bolletjes wilt u?"))
#if aantal>8:
    #print("Sorry, zulke grote bakken hebben we niet")
#if aantal<0:
    #print("Sorry dat snap ik niet")
    #terug naar de vraag


#if aantal<=3:
    #vraag=input("Wilt u deze{aantal} bolletje(s) in een hoorntje of een bakje?")
    #if vraag == "bakje":
        #print("Hier is uw bakje met {aantal}bolletje(s)")
    #elif vraag == "hoorntje":
        #print("Hier is uw hoorntje met {aantal} bolletje(s)")
    #else:  
        #print("Sorry dat snap ik niet")
        #terug naar de vraag

        #meer = input("Wilt u nog meer bestellen?")
        #if meer == "ja":
            #hij gaat terug naar stap 1
        #elif meer == "nee":
            #print("Bedankt en tot ziens!")
        #else:
            #print("Sorry dat snap ik niet")
            #terug naar de vraag


#if aantal >3:
    #print("Dan krijgt u van mij een bakje met(",aantal,") bolletjes")
    #print("Hier is uw bakje met {aantal}bolletje(s)")

#else:
    #print("sorry dat snap ik niet")
    #terug naar de vraag

