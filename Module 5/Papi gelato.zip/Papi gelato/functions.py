from data import *

def welkom():
    print("Welkom bij Papi Gelato je mag alle smaken kiezen als het maar vanille smaak is")
def aantalbolletjes():
    doorgaan = True
    while doorgaan == True:
        try:
            aantal = int(input("Hoeveel bolletje(s) wilt u?"))
        except:
            print("Sorry, dat snap ik niet")
            continue

        if aantal > 8:
            print("Sorry, zulke grote bakken hebben we niet")
            continue
            
        elif aantal <= 0:
            print("Sorry, dat snap ik niet")
            
        elif aantal >= 1 and aantal <= 3:
            break

        elif aantal >= 4 and aantal <= 8:
            break

    return aantal

        

def verpakking(aantal:int):

    again = True
    while again == True:
        if aantal >= 4 and aantal <= 8:
            keuze = "bakje"
            break
        if aantal >= 1 and aantal <= 3:
            keuze=input("Wilt u een bakje of een hoorntje?").lower()
            if keuze == "bakje":  
                
                break

            elif keuze == "hoorntje":
                
                break
            
            else:
                print("Sorry dat snap ik niet")
                continue
    return keuze

def bestelling(keuze:str, aantal:int):
    print("Dan krijgt u een ",aantal," met",keuze,"bolletje(s)")

def meerbestellen():
    meerbestel = True
    while meerbestel == True:
        meerbestellen = input("Wilt u nog meer bestellen? (ja/nee)").lower()
        if meerbestellen == "ja":
            return True
        elif meerbestellen == "nee":
            print("Bedankt en tot ziens!")
            return False
            break
        else:
            print("Sorry, dat snap ik niet")
            continue

            