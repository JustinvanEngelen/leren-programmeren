prijzen={
    "bolletjes" : 0.95,
    "hoorntjes" : 1.25,
    "bakjes"    : 0.75,
    "slagroom"  : 0.50,
    "sprinkels" : 0.30,
    "caramel"   : 0.60,
    "liter"     : 9.80
}

aantallen={
    "bolletjes" : 0,
    "hoorntjes" : 0,
    "bakjes"    : 0,
    "liter"     : 0,
}

smaken={
    "a" : "aardbei",
    "c" : "chocolade",
    "v" : "vanille",

}
litersmaken={
    "a" : "aardbei",
    "c" : "chocolade",
    "v" : "vanille",

}
smakenaantal={
    "a" : 0,
    "c" : 0,
    "v" : 0,

}
litersmakenaantal={
    "a" : 0,
    "c" : 0,
    "v" : 0,

}

topping={
    "b" : "slagroom",
    "c" : "sprinkels",
    "d" : "caramel"
}

toppingsaantal={
    "slagroom" : 0,
    "sprinkels" : 0,
    "caramel" : 0
}